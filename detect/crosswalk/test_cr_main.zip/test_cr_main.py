from aigo_cr_test import cr_run

res = cr_run()
print("\nresult : ", res)