from aigo_server_test2 import tl_run

res = tl_run()
print("result : ", res)
